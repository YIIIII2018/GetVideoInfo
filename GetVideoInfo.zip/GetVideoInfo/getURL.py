'''
学号：whu2018282110414
姓名：易晓博

处理爬虫日志，从中爬取视频信息，包括人气、播放量、URL等等信息
'''
import re

def read_file_list(inputFile):
    results = ""
    fin = open(inputFile, 'r', encoding='UTF-8')
    for eachLine in fin.readlines():
        results+=eachLine
    fin.close()
    results=str(results)
    return results


def get_info(inputFile):
    # 第一步把一个包的所有URL信息取出来
    tmp1 = read_file_list(inputFile)
    # print(re.findall(r"{(.*)}", tmp1))

    # 把头部无用的信息去掉
    tmp2 = re.findall(r"{(.*)}", tmp1)

    # 把剩下的信息，按每个视频分出来
    tmp3 = re.findall(r'{"heads"(.+?)"tags":\[]}', tmp2[0])
    myInfo=[]
    for i in tmp3:
        #print(i)
        tmpInfo=[]
        # 现在把每个视频信息的分段，依次提取出视频地址、播放量等等信息
        # 标题
        caption1 = re.findall(r'caption":"(.+?)","',i)
        print(caption1[0])
        # 评论数
        comment_count1 = re.findall(r'"comment_count":(.+?),"', i)
        print(comment_count1[0])
        # 播放量
        view_count1 = re.findall(r'"view_count":(.+?),"', i)
        print(view_count1[0])
        # 关注度
        like_count1 = re.findall(r'"like_count":(.+?),"',i)
        print(like_count1[0])
        # 用户ID
        user_id1 = re.findall(r'"user_id":(.+?),"', i)
        print(user_id1[0])
        # 视频URL,URL有多种格式，分批次处理
        url1 = re.findall(r'{"cdn":"alimov2.a.yximgs.com","url":"(.+?)"}', i)
        #url2 = re.findall(r'{"cdn":"jsmov2.a.yximgs.com", "url": "(.+?)"},{"cdn"', i)
        #print(url1[0])

        tmpInfo.append(caption1[0])
        tmpInfo.append(comment_count1[0])
        tmpInfo.append(view_count1[0])
        tmpInfo.append(like_count1[0])
        tmpInfo.append(user_id1[0])
        if(len(url1)==0):
            tmpInfo.append("")
        else:
            tmpInfo.append(url1[0])

        myInfo.append(tmpInfo)
    return myInfo



