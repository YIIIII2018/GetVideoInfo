#-*- coding: UTF-8 -*-

'''
学号：whu2018282110414
姓名：易晓博

下载视频
'''


import urllib
import urllib.request
import time
import getURL

def getVideo():
    test1 = getURL.get_info(r'D:\Downloads\Fiddler\476_Full.txt')
    #print("===================================================")
    for i in test1:
        for j in i:
            print(j)
    count_video=0
    for i in test1:
        count_video+=1
        tmpURL=i[5]
        #之所以判断URL非空，一方面是为了程序健壮性，另一方面爬虫还需求改进
        if(tmpURL!=""):
            print("正在下载该包的第%s个视频" %count_video)
            res = urllib.request.urlopen(tmpURL)
            urllib.request.urlretrieve(tmpURL,r'D:\Downloads\Fiddler\%s.mp4' %count_video)
            print("=================================")
        time.sleep(15)

getVideo()
