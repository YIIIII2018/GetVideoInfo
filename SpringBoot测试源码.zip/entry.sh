#!/bin/bash

cd `dirname $0`
cd /code
mvn clean package
# mvn package
