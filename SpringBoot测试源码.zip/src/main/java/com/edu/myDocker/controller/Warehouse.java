package com.edu.myDocker.controller;

import com.edu.myDocker.utils.DbUtils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableAutoConfiguration
@RequestMapping("/warehouse")
public class Warehouse extends ControllerBase {
//    private static final Logger LOGGER=Logger.getLogger(Warehouse.class);
    private Connection conn=null;
    private PreparedStatement pstmt = null;
    private ResultSet rs = null;
    private String driverClassName="org.apache.hive.jdbc.HiveDriver";  
    private String url="jdbc:hive2://spark-master:10000";  
    private String userName="root";  
    private String password="";  

    @RequestMapping(path = "database", method = RequestMethod.GET)
    HashMap listdatabase(@RequestParam(name="filter", required=false, defaultValue="") String filter) throws ClassNotFoundException, SQLException {

        String sql = "show databases";
        List<HashMap> db_list = new ArrayList<>();
        conn = DbUtils.getConnection(driverClassName, url, userName, password);             
        pstmt = DbUtils.getStmt(conn, sql);
        rs = DbUtils.getRs(pstmt);
        while(rs.next()) {
            HashMap db = new HashMap();
            String name = rs.getString(1);
            db.put("name", name);
            db.put("create_time", 1545973457);
            db_list.add(db);
        }
        AddData("database", db_list);
        DbUtils.closeAll(conn, pstmt, rs);
        return GetRet();
    }

    @RequestMapping(path = "database/{dbname}", method = RequestMethod.POST)
    HashMap newdatabase(@PathVariable("dbname") String dbname){
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
        String sql = "CREATE DATABASE IF NOT EXISTS"+ dbname +
                "COMMENT comment" +
                "LOCATION hdfs:///user/hive/warehouse/" +
                "WITH DBPROPERTIES('creator' = 'someone', 'create_time' = "+df.format(new Date())+")";
        String status = "";
        try {   
            conn = DbUtils.getConnection(driverClassName, url, userName, password);
            conn.setAutoCommit(false);
            pstmt = DbUtils.getStmt(conn, sql);
            pstmt.executeUpdate();
            conn.commit();
            status = "true";
        } catch (ClassNotFoundException ex) {
            status = "false";
        } catch (SQLException ex) {
            status = "false";
        }finally{
            try {
                DbUtils.closeAll(conn, pstmt, rs);
            } catch (SQLException ex) {
                status = "false";
            }
        }
        AddData("status", status);
        
        return GetRet();
    }

    @RequestMapping(path = "database/deleteDatabase", method = RequestMethod.DELETE)
    HashMap deletDatabase(@PathVariable("dbname") String dbname) {
        String sql = "DROP DATABASE IF EXISTS "+dbname+" CASCADE";
        String status = "";
        try {   
            conn = DbUtils.getConnection(driverClassName, url, userName, password);
            conn.setAutoCommit(false);
            pstmt = DbUtils.getStmt(conn, sql);
            pstmt.executeUpdate();
            conn.commit();
            status = "true";
        } catch (ClassNotFoundException ex) {
            status = "false";
        } catch (SQLException ex) {
            status = "false";
        }finally{
            try {
                DbUtils.closeAll(conn, pstmt, rs);
            } catch (SQLException ex) {
                status = "false";
            }
        }
        AddData("status", status);
        return GetRet();
    }
    
    @RequestMapping(path = "table/{dbName}", method = RequestMethod.GET)
    HashMap listTables(@PathVariable(name="dbName",required=true)String dbName)throws ClassNotFoundException, SQLException{
        String sql = "show tables";
        String url1=url+"/"+dbName;
        List<HashMap> table_list = new ArrayList<>();
        conn = DbUtils.getConnection(driverClassName, url1, userName, password);             
        pstmt = DbUtils.getStmt(conn, sql);
        rs = DbUtils.getRs(pstmt);
        while(rs.next()) {
            HashMap table = new HashMap();
            String name = rs.getString(2);
            table.put("name", name);
            table_list.add(table);
        }
        AddData("tables", table_list);
        DbUtils.closeAll(conn, pstmt, rs);
        return GetRet();
    }
    
    @RequestMapping(path = "table/{tableName}", method = RequestMethod.POST)
    HashMap newTable(@RequestParam(name = "tableName") String tableName, @RequestParam(name = "dbName") String dbName){
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
        String sql = "";
        String status = "";
        String url1=url+"/"+dbName;
        try {   
            conn = DbUtils.getConnection(driverClassName, url1, userName, password);
            conn.setAutoCommit(false);
            pstmt = DbUtils.getStmt(conn, sql);
            pstmt.executeUpdate();
            conn.commit();
            status = "true";
        } catch (ClassNotFoundException ex) {
            status = "false";
        } catch (SQLException ex) {
            status = "false";
        }finally{
            try {
                DbUtils.closeAll(conn, pstmt, rs);
            } catch (SQLException ex) {
                status = "false";
            }
        }
        AddData("status", status);
        return GetRet();
    }
    
    @RequestMapping(path = "table/deleteTable", method = RequestMethod.DELETE)
    HashMap deleteTable(@RequestParam(name = "tableName") String tableName, @RequestParam(name = "dbName") String dbName){
        String sql = "DROP TABLE IF EXISTS"+tableName;
        String url1=url+"/"+dbName;
        String status = "";
        try {   
            conn = DbUtils.getConnection(driverClassName, url1, userName, password);
            conn.setAutoCommit(false);
            pstmt = DbUtils.getStmt(conn, sql);
            pstmt.executeUpdate();
            conn.commit();
            status = "true";
        } catch (ClassNotFoundException ex) {
            status = "false";
        } catch (SQLException ex) {
            status = "false";
        }finally{
            try {
                DbUtils.closeAll(conn, pstmt, rs);
            } catch (SQLException ex) {
                status = "false";
            }
        }
        AddData("status", status);
        return GetRet();
    }
}
