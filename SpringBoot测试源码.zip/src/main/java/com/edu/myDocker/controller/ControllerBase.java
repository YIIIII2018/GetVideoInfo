package com.edu.myDocker.controller;

import java.util.HashMap;

public class ControllerBase {

    private HashMap ret = new HashMap();

    public ControllerBase() {
        ret.clear();
        ret.put("errno", 0);
        ret.put("errmsg", "");
        ret.put("data", new HashMap());
    }

    public void SetError(int errno, String errmsg) {
        ret.put("errno", errno);
        ret.put("errmsg", errmsg);
        ret.put("data", new HashMap());
    }

    public HashMap GetRet() {
        return ret;
    }

    public void AddData(String key, Object value) {
        ret.put("errno", 0);
        ret.put("errmsg", "");
        ((HashMap) (ret.get("data"))).put(key, value);
    }

}
