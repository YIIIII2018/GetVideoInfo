package com.edu.myDocker.controller;

import com.edu.myDocker.model.entity.FtpTaskEntity;
import com.edu.myDocker.model.mapper.FtpTaskMapper;
import com.edu.myDocker.request.FtpTaskRequest;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableAutoConfiguration
@RequestMapping("/datacollection")
public class DataCollection extends ControllerBase {

    @Autowired
    private FtpTaskMapper FtpTaskMapper;

    @RequestMapping(path = "ftp", method = RequestMethod.POST)
    HashMap createFtpTask(@RequestBody FtpTaskRequest params) {
        if (params.getIp() == null || params.getIp().equals("")) {
            SetError(10001, "Need Params " + params.toString());
            return GetRet();
        }

        FtpTaskEntity t = new FtpTaskEntity();
        t.setIp(params.getIp());
        t.setPort(params.getPort());
        t.setUsername(params.getUsername());
        t.setPassword(params.getPassword());
        t.setDir(params.getDir());
        t.setHdfsdir(params.getHdfsdir());

        FtpTaskMapper.insert(t);

        AddData("id", t.getId());
        return GetRet();
    }

    @RequestMapping(path = "test", method = RequestMethod.GET)
    HashMap test() {
        AddData("testid", 123456);
        return GetRet();
    }

}
