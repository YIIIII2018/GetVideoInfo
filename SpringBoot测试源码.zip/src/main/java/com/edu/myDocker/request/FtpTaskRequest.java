package com.edu.myDocker.request;

import lombok.Data;

@Data
public class FtpTaskRequest {

    private long id;
    private String ip;
    private short port;
    private String username;
    private String password;
    private String dir;
    private boolean subdir;
    private String regex;
    private String hdfsdir;
    private boolean inc;
    private boolean secure;
    private String cron;

}
