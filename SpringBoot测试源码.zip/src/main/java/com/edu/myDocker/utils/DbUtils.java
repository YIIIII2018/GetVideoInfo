/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edu.myDocker.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;


public class DbUtils {
    private static Logger logger=Logger.getLogger(DbUtils.class);
    private static Connection conn=null;  
    private static PreparedStatement pstmt=null;  
    private static ResultSet rs=null;  
//    private static String driverClassName="org.apache.hive.jdbc.HiveDriver";  
//    private static String url="jdbc:hive2://spark-master:10000";  
//    private static String userName="root";  
//    private static String password="";  
    /**
     * 获取数据库连接
     * 
     * @param dirverName
     * @param url
     * @param user
     * @param password
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public static Connection getConnection(String driverClassName, String url, String userName, String password) throws ClassNotFoundException, SQLException {
        try {
            Class.forName(driverClassName);
            conn =DriverManager.getConnection(url, userName, password);
        } catch (ClassNotFoundException ex) {
            logger.error("数据库驱动类加载异常："+ex.getMessage(),ex); 
            throw ex; 
        } catch (SQLException ex) {
            logger.error("获取数据库连接异常："+ex.getMessage(),ex);  
            throw ex; 
        }
        return conn;
    }
    
     public static PreparedStatement getStmt(Connection conn, String sql) throws SQLException{  
        try{  
            pstmt=conn.prepareStatement(sql);  
        }catch(RuntimeException ex){  
            logger.error("获取数据库处理命令异常："+ex.getMessage(),ex);  
            throw ex;  
        }  
        return pstmt;  
    }  
     /**
      * SQL 查询将查询结果直接放入ResultSet中
     * @throws java.sql.SQLException
      */
      public static ResultSet getRs(PreparedStatement pstmt) throws SQLException{  
        try{  
            rs=pstmt.executeQuery();  
        }catch(RuntimeException ex){  
            logger.error("获取查询结果发生异常："+ex.getMessage(),ex);  
            throw ex;  
        }  
        return rs;  
    } 
      
      public static void closeAll(Connection conn, PreparedStatement pstmt, ResultSet rs) throws SQLException{  
        try{  
            if(rs!=null)rs.close();  
            if(pstmt!=null)pstmt.close();  
            if(conn!=null)conn.close();  
        }catch(RuntimeException ex){  
            logger.error("数据库关闭项异常："+ex.getMessage(),ex);  
            throw ex;  
        }  
    } 
}
