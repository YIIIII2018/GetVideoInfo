package com.edu.myDocker.model.mapper;

import com.edu.myDocker.model.entity.FtpTaskEntity;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface FtpTaskMapper {

    @Select("SELECT * FROM ftp_tasks")
    List<FtpTaskEntity> getAll();

    @Select("SELECT * FROM ftp_tasks WHERE id = #{id}")
    FtpTaskEntity getOne(Long id);

    @Insert("INSERT INTO ftp_tasks(ip,port,username,password, dir, hdfsdir) VALUES(#{ip}, #{port}, #{username}, #{password}, #{dir}, #{hdfsdir})")
    @SelectKey(statement = "select LAST_INSERT_ID()", keyProperty = "id", before = false, resultType = int.class)
    void insert(FtpTaskEntity task);

    @Update("UPDATE ftp_tasks SET ip=#{ip},port=#{port},username=#{username},password=#{password},dir=#{dir},hdfsdir=#{hdfsdir} WHERE id =#{id}")
    void update(FtpTaskEntity task);

    @Delete("DELETE FROM ftp_tasks WHERE id =#{id}")
    void delete(Long id);

}
